import 'package:flutter/material.dart';

class ShopScreen extends StatefulWidget {
  const ShopScreen({super.key});

  @override
  State<ShopScreen> createState() => _ShopScreenState();
}

class _ShopScreenState extends State<ShopScreen> {
  int _currentIndex = 0;
  final TextEditingController _searchController = TextEditingController();
  List<String> searchHistory = ['Pink Ribbon Nails', 'French Nails', 'Glitter'];
  
  final List> products = [
    {'name': 'Pink Ribbon Nails', 'price': 49000, 'image': 'assets/nails_1.jpeg', 'rating': 4.9, 'sold': '10rb+'},
    {'name': 'Milky French', 'price': 45000, 'image': 'assets/nails_2.jpeg', 'rating': 4.8, 'sold': '5rb+'},
    {'name': 'Dreamy Bloom', 'price': 52000, 'image': 'assets/nails_3.jpeg', 'rating': 4.9, 'sold': '8rb+'},
    {'name': 'Cute Heart Nails', 'price': 47000, 'image': 'assets/nails_4.jpeg', 'rating': 4.7, 'sold': '3rb+'},
    {'name': 'Sweet Aurora', 'price': 50000, 'image': 'assets/nails_5.jpeg', 'rating': 4.9, 'sold': '12rb+'},
    {'name': 'Elegant Pearls', 'price': 55000, 'image': 'assets/nails_6.jpeg', 'rating': 4.9, 'sold': '6rb+'},
    {'name': 'Glossy Nude', 'price': 42000, 'image': 'assets/nails_7.jpeg', 'rating': 4.6, 'sold': '4rb+'},
    {'name': 'Chrome Sparkle', 'price': 53000, 'image': 'assets/nails_8.jpeg', 'rating': 4.9, 'sold': '9rb+'},
    {'name': 'Butterfly Nails', 'price': 48000, 'image': 'assets/nails_9.jpeg', 'rating': 4.8, 'sold': '7rb+'},
    {'name': 'Matte Velvet', 'price': 46000, 'image': 'assets/nails_10.jpeg', 'rating': 4.7, 'sold': '2rb+'},
  ];

  List> cartItems = [];
  List> orders = [
    {
      'no_pesanan': 'ALY20261115001',
      'produk': 'Pink Ribbon Nails',
      'total': 49000,
      'status': 'Diproses',
      'tanggal': '15 Nov 2026'
    }
  ];

  @override
  Widget build(BuildContext context) {
    final List<Widget> pages = [
      _buildHomeTab(),
      _buildSearchTab(),
      _buildCartTab(),
      _buildOrdersTab(),
      _buildProfileTab(),
    ];

    return Scaffold(
      backgroundColor: const Color(0xFFFFF8F9),
      body: pages[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) => setState(() => _currentIndex = index),
        type: BottomNavigationBarType.fixed,
        selectedItemColor: const Color(0xFFE58B9E),
        unselectedItemColor: Colors.grey,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Beranda'),
          BottomNavigationBarItem(icon: Icon(Icons.search), label: 'Cari'),
          BottomNavigationBarItem(icon: Icon(Icons.shopping_cart), label: 'Keranjang'),
          BottomNavigationBarItem(icon: Icon(Icons.local_shipping), label: 'Pesanan'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profil'),
        ],
      ),
    );
  }

  Widget _buildHomeTab() {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Image.asset('assets/logo.jpeg', width: 40, height: 40, fit: BoxFit.cover),
              ),
              const SizedBox(width: 8),
              const Text(
                'ALYNA',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Color(0xFF884A54), letterSpacing: 1.5),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFFFCE4EC),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Text('New Arrival 💖', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF884A54))),
                      SizedBox(height: 4),
                      Text('Cute Press On Nails Koleksi Terbaru', style: TextStyle(color: Colors.black54, fontSize: 12)),
                    ],
                  ),
                ),
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Image.asset('assets/nails_1.jpeg', width: 60, height: 60, fit: BoxFit.cover),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          const Text('Produk Terlaris ALYNA', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF884A54))),
          const SizedBox(height: 12),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: products.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              childAspectRatio: 0.72,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
            ),
            itemBuilder: (context, index) {
              final product = products[index];
              return GestureDetector(
                onTap: () => _showProductDetail(product),
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    boxShadow: [BoxShadow(color: Colors.pink.withOpacity(0.05), blurRadius: 5, spreadRadius: 2)],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: ClipRRect(
                          borderRadius: const BorderRadius.vertical(top: Radius.circular(14)),
                          child: Image.asset(product['image'] as String, width: double.infinity, fit: BoxFit.cover),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(product['name'] as String, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                            const SizedBox(height: 4),
                            Text('Rp${product['price']}', style: const TextStyle(color: Color(0xFFE58B9E), fontWeight: FontWeight.bold)),
                            const SizedBox(height: 2),
                            Text('⭐ ${product['rating']} | ${product['sold']}', style: const TextStyle(fontSize: 10, color: Colors.grey)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildSearchTab() {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Cari press-on nails...',
                prefixIcon: const Icon(Icons.search, color: Color(0xFFE58B9E)),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
              onSubmitted: (val) {
                if (val.isNotEmpty && !searchHistory.contains(val)) {
                  setState(() => searchHistory.insert(0, val));
                }
              },
            ),
            const SizedBox(height: 16),
            const Text('Riwayat Pencarian', style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF884A54))),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: searchHistory.map((term) => Chip(
                label: Text(term),
                backgroundColor: const Color(0xFFFCE4EC),
                onDeleted: () => setState(() => searchHistory.remove(term)),
              )).toList(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCartTab() {
    int subtotal = cartItems.fold(0, (sum, item) => sum + (item['price'] as int));
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Text('Keranjang Belanja', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF884A54))),
            const SizedBox(height: 16),
            Expanded(
              child: cartItems.isEmpty
                  ? const Center(child: Text('Keranjang masih kosong, yuk belanja! 💅'))
                  : ListView.builder(
                      itemCount: cartItems.length,
                      itemBuilder: (context, index) {
                        final item = cartItems[index];
                        return ListTile(
                          leading: Image.asset(item['image'] as String, width: 50, height: 50, fit: BoxFit.cover),
                          title: Text(item['name'] as String),
                          subtitle: Text('Rp${item['price']}'),
                          trailing: IconButton(
                            icon: const Icon(Icons.delete, color: Colors.red),
                            onPressed: () => setState(() => cartItems.removeAt(index)),
                          ),
                        );
                      },
                    ),
            ),
            if (cartItems.isNotEmpty)
              ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFE58B9E), minimumSize: const Size(double.infinity, 50)),
                onPressed: _showCheckoutNota,
                child: Text('Checkout (${cartItems.length} Produk) - Rp$subtotal', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildOrdersTab() {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Status Pesanan Saya', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF884A54))),
            const SizedBox(height: 12),
            Expanded(
              child: ListView.builder(
                itemCount: orders.length,
                itemBuilder: (context, index) {
                  final order = orders[index];
                  return Card(
                    margin: const EdgeInsets.only(bottom: 12),
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('No. Pesanan: ${order['no_pesanan']}', style: const TextStyle(fontWeight: FontWeight.bold)),
                          Text('Produk: ${order['produk']}'),
                          Text('Total: Rp${order['total']}'),
                          const SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Chip(
                                label: Text(order['status'] as String, style: const TextStyle(color: Colors.white)),
                                backgroundColor: const Color(0xFFE58B9E),
                              ),
                              TextButton(
                                onPressed: () => _showReturnDialog(order),
                                child: const Text('Pengembalian Barang', style: TextStyle(color: Colors.red)),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileTab() {
    return const SafeArea(
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(radius: 40, backgroundColor: Color(0xFFE58B9E), child: Icon(Icons.person, size: 50, color: Colors.white)),
            SizedBox(height: 16),
            Text('Akun Pengguna ALYNA', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF884A54))),
            Text('Terverifikasi via Database Supabase', style: TextStyle(color: Colors.grey)),
          ],
        ),
      ),
    );
  }

  void _showProductDetail(Map<String, dynamic> product) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => Container(
        padding: const EdgeInsets.all(20),
        height: MediaQuery.of(context).size.height * 0.75,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(child: ClipRRect(borderRadius: BorderRadius.circular(16), child: Image.asset(product['image'] as String, height: 200, width: double.infinity, fit: BoxFit.cover))),
            const SizedBox(height: 16),
            Text(product['name'] as String, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Color(0xFF884A54))),
            Text('Rp${product['price']}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFFE58B9E))),
            const SizedBox(height: 12),
            const Text('Kuku buatan tangan berkualitas tinggi, tahan lama, dan mudah diaplikasikan. Sudah termasuk lem dan kikir kuku gratis!', style: TextStyle(color: Colors.black54)),
            const Spacer(),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () {
                      setState(() => cartItems.add(product));
                      Navigator.pop(context);
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Berhasil dimasukkan ke keranjang! 🛒')));
                    },
                    child: const Text('Masukkan Keranjang', style: TextStyle(color: Color(0xFF884A54))),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFE58B9E)),
                    onPressed: () {
                      Navigator.pop(context);
                      setState(() => cartItems.add(product));
                      _showCheckoutNota();
                    },
                    child: const Text('Beli Sekarang', style: TextStyle(color: Colors.white)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showCheckoutNota() {
    int subtotal = cartItems.fold(0, (sum, item) => sum + (item['price'] as int));
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Nota Pembelian ALYNA 🧾', style: TextStyle(color: Color(0xFF884A54))),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('No. Invoice: ALY20261116099'),
            const Text('Tanggal: 16 Nov 2026'),
            const Divider(),
            ...cartItems.map((item) => Text('${item['name']} - Rp${item['price']}')).toList(),
            const Divider(),
            Text('Total Pembayaran: Rp$subtotal', style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFFE58B9E))),
            const SizedBox(height: 10),
            const Text('Status Pesanan: Diproses ➔ Dikemas ➔ Dikirim ➔ Diterima', style: TextStyle(fontSize: 11, color: Colors.grey)),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              setState(() {
                orders.add({
                  'no_pesanan': 'ALY20261116099',
                  'produk': cartItems.isNotEmpty ? cartItems[0]['name'] : 'Press On Nails',
                  'total': subtotal,
                  'status': 'Diproses',
                  'tanggal': '16 Nov 2026'
                });
                cartItems.clear();
              });
              Navigator.pop(context);
              setState(() => _currentIndex = 3);
            },
            child: const Text('Bayar Sekarang', style: TextStyle(color: Color(0xFFE58B9E), fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  void _showReturnDialog(Map<String, dynamic> order) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Pengajuan Pengembalian Barang'),
        content: Text('Ajukan retur/pengembalian untuk pesanan ${order['no_pesanan']}? Tim ALYNA akan segera memprosesnya.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () {
              setState(() => order['status'] = 'Pengembalian Barang');
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Pengembalian barang berhasil diajukan.')));
            },
            child: const Text('Ajukan', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }
}