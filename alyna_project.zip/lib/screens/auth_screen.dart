import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'shop_screen.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool isLogin = true;
  final _namaController = TextEditingController();
  final _emailController = TextEditingController();
  final _teleponController = TextEditingController();
  final _passwordController = TextEditingController();
  bool isLoading = false;

  // Fungsi Validasi & Masuk ke Database Supabase
  void _submitAuth() async {
    final supabase = Supabase.instance.client;
    setState(() => isLoading = true);

    try {
      if (isLogin) {
        // VALIDASI LOGIN: Cek database apakah email/telepon & password cocok
        final response = await supabase
            .from('users')
            .select()
            .or('email.eq.${_emailController.text},telepon.eq.${_emailController.text}')
            .eq('password', _passwordController.text)
            .maybeSingle();

        if (response != null) {
          if (!mounted) return;
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => const ShopScreen()),
          );
        } else {
          _showError('Email/Nomor Telepon atau Password salah! Harap masukkan data yang benar.');
        }
      } else {
        // VALIDASI DAFTAR: Simpan akun baru ke database Supabase
        if (_namaController.text.isEmpty ||
            _emailController.text.isEmpty ||
            _teleponController.text.isEmpty ||
            _passwordController.text.isEmpty) {
          _showError('Semua kolom wajib diisi!');
          setState(() => isLoading = false);
          return;
        }

        await supabase.from('users').insert({
          'nama': _namaController.text,
          'email': _emailController.text,
          'telepon': _teleponController.text,
          'password': _passwordController.text,
          'login_method': 'manual',
          'is_verified': true,
        });

        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Pendaftaran Berhasil! Silakan Login.')),
        );
        setState(() {
          isLogin = true;
          isLoading = false;
        });
      }
    } catch (e) {
      _showError('Terjadi kesalahan koneksi database: $e');
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFF8F9),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Image.asset('assets/logo.jpeg', width: 90, height: 90, fit: BoxFit.cover),
              ),
              const SizedBox(height: 16),
              Text(
                isLogin ? 'Masuk ke ALYNA 💖' : 'Daftar Akun ALYNA',
                style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Color(0xFF884A54)),
              ),
              const SizedBox(height: 24),
              if (!isLogin) ...[
                TextField(
                  controller: _namaController,
                  decoration: InputDecoration(
                    labelText: 'Nama Lengkap',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
                const SizedBox(height: 12),
              ],
              TextField(
                controller: _emailController,
                decoration: InputDecoration(
                  labelText: 'Email atau Nomor Telepon',
                  hintText: 'Contoh: 08123456789 / email@gmail.com',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _passwordController,
                obscureText: true,
                decoration: InputDecoration(
                  labelText: 'Password',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFE58B9E),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  onPressed: isLoading ? null : _submitAuth,
                  child: isLoading
                      ? const CircularProgressIndicator(color: Colors.white)
                      : Text(
                          isLogin ? 'Masuk' : 'Daftar',
                          style: const TextStyle(fontSize: 16, color: Colors.white, fontWeight: FontWeight.bold),
                        ),
                ),
              ),
              const SizedBox(height: 16),
              TextButton(
                onPressed: () => setState(() => isLogin = !isLogin),
                child: Text(
                  isLogin ? 'Belum punya akun? Daftar' : 'Sudah punya akun? Masuk',
                  style: const TextStyle(color: Color(0xFF884A54)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}