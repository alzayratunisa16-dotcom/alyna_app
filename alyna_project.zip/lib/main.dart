import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'screens/splash_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Terhubung langsung ke database Supabase alyna-nails
  const supabaseUrl = 'https://ywxjlpjpvynunftympw.supabase.co';
  const supabaseAnonKey = 'sb_publishable_Ppz4mW4CmTbttEXkSK14mw_uGiw10XZ';

  await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);

  runApp(const AlynaApp());
}

class AlynaApp extends StatelessWidget {
  const AlynaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'ALYNA - Press On Nails',
      theme: ThemeData(
        scaffoldBackgroundColor: const Color(0xFFFFF8F9),
        primaryColor: const Color(0xFFE58B9E),
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFE58B9E)),
        useMaterial3: true,
      ),
      home: const SplashScreen(),
    );
  }
}