package com.example.alyna_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
